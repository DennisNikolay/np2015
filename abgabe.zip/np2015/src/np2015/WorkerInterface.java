package np2015;

public interface WorkerInterface {

}
